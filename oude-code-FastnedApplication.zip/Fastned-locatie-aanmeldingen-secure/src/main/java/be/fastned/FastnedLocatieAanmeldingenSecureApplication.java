package be.fastned;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;

import be.fastned.dao.LocatieRepository;
import be.fastned.domain.Locatie;

@SpringBootApplication
@EnableGlobalMethodSecurity
public class FastnedLocatieAanmeldingenSecureApplication {

	public static void main(String[] args) {
		SpringApplication.run(FastnedLocatieAanmeldingenSecureApplication.class, args);
	}
	
	// locatie initaties
		@Bean
		CommandLineRunner init(LocatieRepository repo) {
			
			return (evt) -> {
				repo.save(new Locatie("Oliver","Brown","Ikea straat", 69, "Brussel", "1000"));
				repo.save(new Locatie("Harry","Thomas","Mc Donals straat", 70, "Brussel", "1000"));
				repo.save(new Locatie("Amy","Angevin","Kinepolis straat", 71, "Gent", "9000"));
				repo.save(new Locatie("Jake","Stuart","Sport Oase straat", 72, "Antwerpen", "2000"));
				repo.save(new Locatie("Ethan","Bruce","Shopping straat", 73, "Mechelen", "2800"));

				
				
			};
		}

}
