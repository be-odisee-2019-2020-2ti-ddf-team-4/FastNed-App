package be.fastned;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FastnedLocatieAanmeldingenSecureApplicationTests {

	@Test
	void contextLoads() {
	}

}
