<template>
  <div class="about">
    <h1>About Fastned Client</h1>
  </div>
</template>
