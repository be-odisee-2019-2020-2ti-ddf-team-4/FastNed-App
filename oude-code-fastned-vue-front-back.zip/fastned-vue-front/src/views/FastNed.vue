<template>
  <div id="fastned">
    <h1>Welkom!</h1>

    <MainForm />

  </div>
</template>
